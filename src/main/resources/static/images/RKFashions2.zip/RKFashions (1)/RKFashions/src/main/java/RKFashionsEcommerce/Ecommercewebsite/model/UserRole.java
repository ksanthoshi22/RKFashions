package RKFashionsEcommerce.Ecommercewebsite.model;

public enum UserRole {
    ROLE_ADMIN,
    ROLE_USER

}
