package RKFashionsEcommerce.Ecommercewebsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommercewebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
