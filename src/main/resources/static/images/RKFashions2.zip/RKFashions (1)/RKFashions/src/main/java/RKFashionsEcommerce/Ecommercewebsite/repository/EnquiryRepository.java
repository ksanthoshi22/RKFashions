package RKFashionsEcommerce.Ecommercewebsite.repository;


import RKFashionsEcommerce.Ecommercewebsite.model.Enquiry;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EnquiryRepository extends JpaRepository<Enquiry, Long> {
}
